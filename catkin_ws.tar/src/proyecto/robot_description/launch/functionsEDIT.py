import numpy as np
from copy import copy
import signal
import sys

pi = np.pi
cos = np.cos
sin = np.sin

def dh(d, theta, a, alpha):
    """
   MATRIZ GENÉRICA DE DH
    """
    sth = np.sin(theta)
    cth = np.cos(theta)
    sa  = np.sin(alpha)
    ca  = np.cos(alpha)
    T = np.array([[cth, -ca*sth,  sa*sth, a*cth],
                  [sth,  ca*cth, -sa*cth, a*sth],
                  [0.0,      sa,      ca,     d],
                  [0.0,     0.0,     0.0,   1.0]])
    return T


def fkine_robot(q):
    """
    Calcular la cinematica directa del robot Majager dados sus valores articulares.
    q es un vector numpy de la forma [q1, q2, q3, q4, q5, q6, q7]

    """
    # Longitudes (en metros)
    #d, theta, a alpha
    # Matrices DH (completar)
    # Matrices DH (completar)
    T0 = dh(0, -np.pi/2,1, 0)
    T1 = dh(0.755, q[0] + np.pi,- 0.235, np.pi / 2)  # Articulación 1
    T2 = dh(0, q[1], 0.8, 0)                         # Articulación 2 (ajustada)
    T3 = dh(0, q[2] - np.pi / 6, 0.13, np.pi / 2)     # Articulación 3
    T4 = dh(0.765, q[3] + np.pi, 0, np.pi / 2)        # Articulación 4
    T5 = dh(0, q[4] + np.pi / 2, 0, np.pi / 2)        # Articulación 5
    T6 = dh(0.280 + q[5], 0, 0, 0)                    # Articulación 6
    T7 = dh(0.0675, q[6], 0, 0)                       # Articulación 7
       # Articulación 7

    # Efector final con respecto a la base
    T = T0 @ T1
    return T 

    # Efector final con respecto a la base
    T = T1@T2@T3@T4
    #T = T1@T2@T3@T4@T5@T6@T7
    return T


def jacobian_position(q, delta=0.0001):
    """
    Jacobiano analitico para la posicion. Retorna una matriz de 3x7 y toma como
    entrada el vector de configuracion articular q=[q1, q2, q3, q4, q5, q6, q7]

    """
    # Alocacion de memoria
    J = np.zeros((3,7))
    # Transformacion homogenea inicial (usando q)
    T = fkine_robot(q)
    # Iteracion para la derivada de cada columna
    for i in range(7):
        # Copiar la configuracion articular inicial (usar este dq para cada
        # incremento en una articulacion)
        dq = copy(q)
        # Incrementar la articulacion i-esima usando un delta
        dq[i] += delta
        # Transformacion homogenea luego del incremento (q+dq)
        T_inc = fkine_robot(dq)
        # Aproximacion del Jacobiano de posicion usando diferencias finitas
        J[:,i] = (T_inc[:3,3]-T[:3,3])/delta

    return J


def ikine_robot(xdes, q0):
    """

    """
    epsilon = 0.001
    max_iter = 10000
    delta = 0.00001
    ee = []
    q = copy(q0)
    cont=0
    for i in range(max_iter):
        cont=cont+1
        # Main loop
        # Calculate the error in position
        T = fkine_robot(q)
        x = T[0:3, 3]
        error = np.array(xdes - x)

        # Check if error is below threshold
        if np.linalg.norm(error) < epsilon:
            break

        # Calculate Jacobian matrix
        J = jacobian_position(q)

        # Use pseudo-inverse of Jacobian for iterative update
        delta_q = np.linalg.pinv(J) @ error

        # Update joint angles
        q += delta_q
        enorm = np.linalg.norm(error)
        ee.append(enorm)

        q[5] = min(max(q[5], 0.0), 0.3)

        # Check for convergence
        if np.linalg.norm(delta_q) < delta:
            break

    return q, ee, cont, epsilon


def ikine_majager_gradiente(xdes, q0, alpha=0.01):

    epsilon = 0.001
    max_iter = 10000
    delta = 0.00001
    ee = []
    q = copy(q0)
    cont=0
    for i in range(max_iter):
        cont = cont + 1
        # Main loop
        # Calculate the error in position
        T = fkine_robot(q)
        x = T[0:3, 3]
        error = np.array(xdes - x)

        # Check if error is below threshold
        if np.linalg.norm(error) < epsilon:
            break

        # Calculate Jacobian matrix
        J = jacobian_position(q)

        # Use pseudo-inverse of Jacobian for iterative update
        delta_q = alpha*(J.T @ error)

        # Update joint angles
        q += delta_q
        enorm = np.linalg.norm(error)
        ee.append(enorm)
        q[5] = min(max(q[5], 0.0), 0.3)

        # Check for convergence
        if np.linalg.norm(delta_q) < delta:
            break

    return q, ee, cont, epsilon

def jacobian_pose(q, delta=0.0001):
 
    J = np.zeros((7, 7))
    T = fkine_robot(q)
    R = TF2xyzquat(T)
    # Iteracion para la derivada de cada articulacion (columna)
    for i in range(7):
        # Copiar la configuracion articular inicial
        dq = copy(q)
        # Calcular nuevamenta la transformacion homogenea e
        # Incrementar la articulacion i-esima usando un delta
        dq[i] = dq[i] + delta
        # Transformacion homogenea luego del incremento (q+delta)
        T_inc = fkine_robot(dq)
        R_inc = TF2xyzquat(T_inc)
        # Aproximacion del Jacobiano de posicion usando diferencias finitas
        # J[0:a,i]=(T_inc[]-T[])/delta
        J[:, i] = (R_inc - R) / delta

    return J



def rot2quat(R):
    """
    Convertir una matriz de rotacion en un cuaternion

    Entrada:
      R -- Matriz de rotacion
    Salida:
      Q -- Cuaternion [ew, ex, ey, ez]

    """
    dEpsilon = 1e-6
    quat = 4*[0.,]

    trace = R[0,0] + R[1,1] + R[2,2]
    if trace > 0:
        quat[0] = 0.5 * np.sqrt(trace + 1.0)
        s = 1.0 / (4.0 * quat[0])
        quat[1] = (R[2,1] - R[1,2]) * s
        quat[2] = (R[0,2] - R[2,0]) * s
        quat[3] = (R[1,0] - R[0,1]) * s
    else:
        if R[0,0] > R[1,1] and R[0,0] > R[2,2]:
            quat[1] = 0.5 * np.sqrt(1.0 + R[0,0] - R[1,1] - R[2,2])
            s = 1.0 / (4.0 * quat[1])
            quat[0] = (R[2,1] - R[1,2]) * s
            quat[2] = (R[1,0] + R[0,1]) * s
            quat[3] = (R[0,2] + R[2,0]) * s
        elif R[1,1] > R[2,2]:
            quat[2] = 0.5 * np.sqrt(1.0 + R[1,1] - R[0,0] - R[2,2])
            s = 1.0 / (4.0 * quat[2])
            quat[0] = (R[0,2] - R[2,0]) * s
            quat[1] = (R[1,0] + R[0,1]) * s
            quat[3] = (R[2,1] + R[1,2]) * s
        else:
            quat[3] = 0.5 * np.sqrt(1.0 + R[2,2] - R[0,0] - R[1,1])
            s = 1.0 / (4.0 * quat[3])
            quat[0] = (R[1,0] - R[0,1]) * s
            quat[1] = (R[0,2] + R[2,0]) * s
            quat[2] = (R[2,1] + R[1,2]) * s

    return np.array(quat)


def TF2xyzquat(T):
    """
    Convert a homogeneous transformation matrix into the a vector containing the
    pose of the robot.

    Input:
      T -- A homogeneous transformation
    Output:
      X -- A pose vector in the format [x y z ew ex ey ez], donde la first part
           is Cartesian coordinates and the last part is a quaternion
    """
    quat = rot2quat(T[0:3,0:3])
    res = [T[0,3], T[1,3], T[2,3], quat[0], quat[1], quat[2], quat[3]]
    return np.array(res)


def skew(w):
    R = np.zeros([3,3])
    R[0,1] = -w[2]; R[0,2] = w[1]
    R[1,0] = w[2];  R[1,2] = -w[0]
    R[2,0] = -w[1]; R[2,1] = w[0]
    return R

def rotx(ang): #Rotacion en x
    Rx = np.array([[1, 0, 0],
                   [0, cos(ang), -sin(ang)],
                   [0, sin(ang), cos(ang)]])
    return Rx

def roty(ang): #Rotacion en y
    Ry = np.array([[cos(ang), 0, sin(ang)],
                   [0, 1, 0],
                   [-sin(ang), 0, cos(ang)]])
    return Ry

def rotz(ang): #Rotacion en z
    Rz = np.array([[cos(ang), -sin(ang), 0],
                   [sin(ang), cos(ang), 0],
                   [0,0,1]])
    return Rz

