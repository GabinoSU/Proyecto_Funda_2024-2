#!/usr/bin/env python3
import numpy as np
import rospy
from sensor_msgs.msg import JointState
from markersEDIT import *
from functionsEDIT import *

pi = np.pi

if __name__ == '__main__':

    rospy.init_node("testForwardKine")
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)
    bmarker = BallMarker(color['GREEN'])

    # Joint names (deben coincidir con el URDF)
    jnames = ['Revolucion_1', 'Revolucion_2', 'Revolucion_3', 'Corredera_4', 
              'Revolucion_5', 'Corredera_6', 'Revolucion_7']

    # Joint configuration (dentro de los límites)
    q = np.array([0, 0, 0, 0, 0, 0, 0])  # Ajusta según sea necesario

    # Aplicar límites a las articulaciones (revisar en el URDF)
    q[1] = min(max(q[1], -1.86), 1.89)
    q[2] = min(max(q[2], -3.14), 1.23)
    q[3] = min(max(q[3], -0.99), 0.0)
    q[5] = min(max(q[5], -0.56), 0.0)

    # Calcular la cinemática directa
    T = fkine_robot(q)
    print("\nArticulaciones:")
    print(f"q1: {q[0]:.3f} rad, q2: {q[1]:.3f} rad, q3: {q[2]:.3f} rad")
    print(f"q4: {q[3]:.3f} rad, q5: {q[4]:.3f} rad, q6: {q[5]:.3f} m, q7: {q[6]:.3f} rad")
    print("Matriz de transformación:")
    print(np.round(T, 3))
    print("\n")

    # Publicar la posición del efector final
    bmarker.position(T)

    # Mensaje JointState
    jstate = JointState()
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames  # Nombres de las articulaciones (deben coincidir con el URDF)
    jstate.position = q  # Posiciones articulares

    # Frecuencia de publicación
    rate = rospy.Rate(50)  # Hz
    while not rospy.is_shutdown():
        jstate.header.stamp = rospy.Time.now()
        pub.publish(jstate)  # Publicar el mensaje
        bmarker.publish()    # Publicar el marcador
        rate.sleep()
