import numpy as np
from copy import copy
pi = np.pi

# PARÁMETROS DE DH
def dh(d, theta, a, alpha):
    """
    Calcular la matriz de transformacion homogenea asociada con los parametros
    de Denavit-Hartenberg.
    Los valores d, theta, a, alpha son escalares.
    """
    sth = np.sin(theta)
    cth = np.cos(theta)
    sa  = np.sin(alpha)
    ca  = np.cos(alpha)
    T = np.array([[cth, -ca*sth,  sa*sth, a*cth],
                  [sth,  ca*cth, -sa*cth, a*sth],
                  [0.0,      sa,      ca,     d],
                  [0.0,     0.0,     0.0,   1.0]])
    return T

# CINEMÁTICA DIRECTA DEL ROBOT (1_TEST_FKINE)
def fkine_kr20(q):
    """
    Calcular la cinematica directa del robot UR5 dados sus valores articulares. 
    q es un vector numpy de la forma [q1, q2, q3, q4, q5, q6, q7]
    """
        # Matrices DH (completar), emplear la funcion dh con los parametros DH para cada articulacion
    T1 = dh(0.755,   q[0],            0,       pi/2)       # Articulación 1 (Revoluta)
    T2 = dh(0,    q[1]-pi/2,    0.235,   -pi/2)      # Articulación 2 (Revoluta)
    T3 = dh(0,              q[2],            -1.5,     0)            # Articulación 3 (Revoluta)
    T4 = dh(1.2,           0,               q[3],     0)            # Articulación 4 (Prismática)
    T5 = dh(0.980,              q[4],            0,     -pi/2)      # Articulación 5 (Revoluta)
    T6 = dh(-0.225 ,   0,              q[5] + 0.1,       0)            # Articulación 6 (Prismática)
    T7 = dh(0,         q[6],            0.5775,       0)            # Articulación 7 (Revoluta)
    # Efector final con respecto a la base
    T = T1 @ T2 @ T3 @ T4 @ T5 @ T6 @ T7
    return T

# JACOBIANO ANALÍTICO PARA EL MÉTODO DE NEWTON
def jacobian(q, delta=0.0001):
 """
 Jacobiano analitico para la posicion de un brazo robotico de n grados de libertad. 
 Retorna una matriz de 3xn y toma como entrada el vector de configuracion articular 
 q=[q1, q2, q3, ..., qn]
 """
 # Crear una matriz 3xn
 n = q.size
 J = np.zeros((3,n))
 # Calcular la transformacion homogenea inicial (usando q)
 T = fkine_kr20(q)   
 # Iteracion para la derivada de cada articulacion (columna)
 for i in range(n):
  # Copiar la configuracion articular inicial
  dq = copy(q)
  # Calcular nuevamenta la transformacion homogenea e
  # Incrementar la articulacion i-esima usando un delta
  dq[i] += delta
  # Transformacion homogenea luego del incremento (q+delta)
  T_inc = fkine_kr20(dq)
  # Aproximacion del Jacobiano de posicion usando diferencias finitas
  J[0:3,i]=(T_inc[0:3,3]-T[0:3,3])/delta
 return J


# CINEMÁTICA INVERSA DEL ROBOT (2_TEST_IKINE)
def ikine(xdes, q0):
 """
 Calcular la cinematica inversa de un brazo robotico numericamente a partir 
 de la configuracion articular inicial de q0. Emplear el metodo de newton.
 """
 epsilon  = 0.001
 max_iter = 1000
 q  = copy(q0)
 for i in range(max_iter):
  # Calcular la posición actual del efector final
  T = fkine_kr20(q)
  pos = T[0:3,3]
  # Error de posición
  error = np.linalg.norm(xdes-pos)
  if error < epsilon:
    break
  # Jacobiano
  J = jacobian(q)
  # Actualizaar el valor de las articulaciones
  dq = np.linalg.pinv(J)@(xdes-pos)
  q = q+dq
  #np.add(q,dq,out=q,casting="unsafe")

 return q


def jacobian_position(q, delta=0.0001):
    """
    Jacobiano analitico para la posicion. Retorna una matriz de 3x7 y toma como
    entrada el vector de configuracion articular q=[q1, q2, q3, q4, q5, q6, q7]
    """
    # Alocacion de memoria
    J = np.zeros((3,7))
    # Transformacion homogenea inicial (usando q)
    T = fkine_kr20(q)
    x = T[0:3,3]
    # Iteracion para la derivada de cada columna
    for i in range(7):
        # Copiar la configuracion articular inicial (usar este dq para cada
        # incremento en una articulacion)
        dq = copy(q)
        # Incrementar la articulacion i-esima usando un delta
        dq[i] = dq[i] + delta
        # Transformacion homogenea luego del incremento (q+dq)
        dx = fkine_kr20(dq)[0:3,3]
        # Aproximacion del Jacobiano de posicion usando diferencias finitas
        columna_i = (dx - x)/delta
        J[:,i] = columna_i
    return J

def jacobian_position2(q, delta=0.0001):
    """
    Jacobiano analitico para la posicion. Retorna una matriz de 3x9 y toma como
    entrada el vector de configuracion articular q=[q1, q2, q3, q4, q5, q6, q7, q8, q9]
    """
    # Alocacion de memoria
    J = np.zeros((3,9))
    # Transformacion homogenea inicial (usando q)
    T = fkine_kr20(q)
    x = T[0:3,3]
    # Iteracion para la derivada de cada columna
    for i in range(9):
        # Copiar la configuracion articular inicial (usar este dq para cada
        # incremento en una articulacion)
        dq = copy(q)
        # Incrementar la articulacion i-esima usando un delta
        dq[i] = dq[i] + delta
        # Transformacion homogenea luego del incremento (q+dq)
        dx = fkine_kr20(dq)[0:3,3]
        # Aproximacion del Jacobiano de posicion usando diferencias finitas
        columna_i = (dx - x)/delta
        J[:,i] = columna_i
    return J


def jacobian_pose(q, delta=0.0001):
    """
    Jacobiano analitico para la posicion y orientacion (usando un
    cuaternion). Retorna una matriz de 7x7 y toma como entrada el vector de
    configuracion articular q=[q1, q2, q3, q4, q5, q7]
    """
    J = np.zeros((7,7))
    # Implementar este Jacobiano aqui
    T = fkine_kr20(q)
    for i in range(7):
      x = TF2xyzquat(T)
      dq = copy(q)
      dq[i] = dq[i] + delta
      Tf = fkine_kr20(dq)
      xf = TF2xyzquat(Tf)
      J[0,i] = (xf[0] - x[0])/delta
      J[1,i] = (xf[1] - x[1])/delta
      J[2,i] = (xf[2] - x[2])/delta
      J[3,i] = (xf[3] - x[3])/delta
      J[4,i] = (xf[4] - x[4])/delta
      J[5,i] = (xf[5] - x[5])/delta
      J[6,i] = (xf[6] - x[6])/delta
    return J



def rot2quat(R):
    """
    Convertir una matriz de rotacion en un cuaternion
    Entrada:
      R -- Matriz de rotacion
    Salida:
      Q -- Cuaternion [ew, ex, ey, ez]
    """
    dEpsilon = 1e-6
    quat = 4*[0.,]

    quat[0] = 0.5*np.sqrt(R[0,0]+R[1,1]+R[2,2]+1.0)
    if ( np.fabs(R[0,0]-R[1,1]-R[2,2]+1.0) < dEpsilon ):
        quat[1] = 0.0
    else:
        quat[1] = 0.5*np.sign(R[2,1]-R[1,2])*np.sqrt(R[0,0]-R[1,1]-R[2,2]+1.0)
    if ( np.fabs(R[1,1]-R[2,2]-R[0,0]+1.0) < dEpsilon ):
        quat[2] = 0.0
    else:
        quat[2] = 0.5*np.sign(R[0,2]-R[2,0])*np.sqrt(R[1,1]-R[2,2]-R[0,0]+1.0)
    if ( np.fabs(R[2,2]-R[0,0]-R[1,1]+1.0) < dEpsilon ):
        quat[3] = 0.0
    else:
        quat[3] = 0.5*np.sign(R[1,0]-R[0,1])*np.sqrt(R[2,2]-R[0,0]-R[1,1]+1.0)

    return np.array(quat)


def TF2xyzquat(T):
    """
    Convert a homogeneous transformation matrix into the a vector containing the
    pose of the robot.
    Input:
      T -- A homogeneous transformation
    Output:
      X -- A pose vector in the format [x y z ew ex ey ez], donde la first part
           is Cartesian coordinates and the last part is a quaternion
    """
    quat = rot2quat(T[0:3,0:3])
    res = [T[0,3], T[1,3], T[2,3], quat[0], quat[1], quat[2], quat[3]]
    return np.array(res)

def skew(w):
    R = np.zeros([3,3])
    R[0,1] = -w[2]; R[0,2] = w[1]
    R[1,0] = w[2];  R[1,2] = -w[0]
    R[2,0] = -w[1]; R[2,1] = w[0]
    return R